import { Component } from '@angular/core';
import { AuthenticationService } from './authentication.service';
import { Router } from '@angular/router';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'BillManagement';
  constructor(private router:Router,private authService:AuthenticationService) { }
  isMenuDisplayed!:boolean;
  ngOnInit(): void {
  }

  onSelectedMenuItem(menuItem:string){
    console.log("onSelect");
    
    if(menuItem==='view-driver-details-component'){
    this.router.navigateByUrl('viewByDriver');
    }
    if(menuItem==='view-bill-component'){
      this.router.navigateByUrl('viewBill');
    }
    if(menuItem==='add-component'){
      this.router.navigateByUrl('addcomponent');
    }


    if(menuItem==='logOut'){
      this.authService.logOut();
      alert("Logout Successfully")
      this.router.navigateByUrl('login');
    }
    if(menuItem==='menu'){
      this.router.navigateByUrl('menu');
    }

    if(menuItem==='home'){
      this.router.navigateByUrl('home');
    }
  }
  togglebutton(){
    console.log(this.isMenuDisplayed);
    this.isMenuDisplayed=!this.isMenuDisplayed;
  }
 
}
