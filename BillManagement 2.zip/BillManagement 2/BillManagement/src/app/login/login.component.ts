import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl,Validators, EmailValidator} from '@angular/forms';
import { BillManagementService } from '../bill-management.service';
import { Router } from '@angular/router';
import { AuthenticationService } from '../authentication.service';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private billManagementService:BillManagementService, private router:Router,private authenticateservice:AuthenticationService ) { }
  loginForm!:FormGroup;
  invalidLogin!:boolean;
  ngOnInit(): void {
    this.loginForm=new FormGroup({

      email:new FormControl('seeker1@gmail.com',[Validators.required,Validators.pattern("^[a-z0-9]+@gmail\.com$")]),
      user_Role:new FormControl('RideSeeker',Validators.required),
      password:new FormControl('user04',[Validators.required, Validators.maxLength(6)]),
    }
    );
}

onSubmit(){  
  this.verify();
  }
  async verify(){
    
    let valid=await this.authenticateservice.authenticate(this.loginForm.value);
    if (valid && this.authenticateservice.isUserLoggedIn()) {
      alert("Login successfully")
      this.router.navigate(['/menu'])
      this.invalidLogin = false
    } else
      this.invalidLogin = true;
     
  }
  }

