export class BillManagement {
     billId!:string;
         rideId!:string;
         noOfKm!:number;
         totalBill!:number;
         noOfOccupants!:number;
         costPerOccupant!:number;
         month!:number;
         driverId!:string;
         feeId!:number;
         fees !:{
            feeId:number;
            carType:string;
            carName:string;
            fuelType:string;
            averageInKm:number;
            costOfFuel:number;
            wearTearCost:number;
            driverCharges:number;
            carPoolCommission:number;
         };
}

export class Login {
   user_Name!: string;
   user_Role!:string;
   password!:string;
   email!:string;
}

export class DriverDetails {
   driverId!:string;
   feeId!:number;
   source!:string;
   destination!:string;
   rideDate!:Date;
   rideStatus!:string;
   bill!:number;
   rideTime!:string;

}
   
