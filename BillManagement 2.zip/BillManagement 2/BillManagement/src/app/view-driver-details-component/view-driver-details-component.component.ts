
import { Component, OnInit } from '@angular/core';
import { BillManagement } from '../bill-management';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { BillManagementService } from '../bill-management.service';
import { DriverDetails } from '../bill-management';

@Component({
  selector: 'app-view-driver-details-component',
  templateUrl: './view-driver-details-component.component.html',
  styleUrls: ['./view-driver-details-component.component.css']
})

export class ViewDriverDetailsComponentComponent implements OnInit {

 viewDriverDetailsFormGroup!:FormGroup;
  flag!:boolean;
constructor(private billManagementService:BillManagementService) { }
  driverDetails!:DriverDetails[];
  billManagementReport:BillManagement=new BillManagement();

  ngOnInit(): void {
    this.viewDriverDetailsFormGroup=new FormGroup({
      driverId:new FormControl('RPAN01',[Validators.required,Validators.pattern(/^RP[A-Za-z]{2}\d{2}$/)]),
      month:new FormControl('3', [Validators.required,Validators.pattern(/^(0?[1-9]|1[0-2])$/)])
    });
  }
  
  submitForm(){
    this.flag=false;
  this.billManagementReport.driverId=this.viewDriverDetailsFormGroup.get('driverId')?.value;
 this.billManagementReport.month=this.viewDriverDetailsFormGroup.get('month')?.value;
    this.view();
}

view(){
    this.billManagementService.viewDriver(this.billManagementReport)
        .subscribe(data =>{
          this.flag=true;
          this.driverDetails=data;
        },
        error=>{
          this.flag=false;
          alert("Error:"+error.error);
        }
          ); 
          this.driverDetails;
  }
}
