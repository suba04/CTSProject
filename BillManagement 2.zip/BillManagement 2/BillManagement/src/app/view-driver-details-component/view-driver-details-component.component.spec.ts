import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewDriverDetailsComponentComponent } from './view-driver-details-component.component';

describe('ViewDriverDetailsComponentComponent', () => {
  let component: ViewDriverDetailsComponentComponent;
  let fixture: ComponentFixture<ViewDriverDetailsComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewDriverDetailsComponentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewDriverDetailsComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
