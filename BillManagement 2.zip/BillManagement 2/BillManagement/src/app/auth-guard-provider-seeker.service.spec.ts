import { TestBed } from '@angular/core/testing';

import { AuthGuardProviderSeekerService } from './auth-guard-provider-seeker.service';

describe('AuthGuardProviderSeekerService', () => {
  let service: AuthGuardProviderSeekerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuthGuardProviderSeekerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
