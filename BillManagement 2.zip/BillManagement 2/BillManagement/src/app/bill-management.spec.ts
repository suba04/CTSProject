import { BillManagement } from './bill-management';

describe('BillManagement', () => {
  it('should create an instance', () => {
    expect(new BillManagement()).toBeTruthy();
  });
});
