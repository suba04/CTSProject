import { TestBed } from '@angular/core/testing';

import { AuthGuardproviderService } from './auth-guardprovider.service';

describe('AuthGuardproviderService', () => {
  let service: AuthGuardproviderService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuthGuardproviderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
