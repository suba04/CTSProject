import { NgModule } from '@angular/core';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { MenuComponent } from './menu/menu.component';
import { RouterModule, Routes } from '@angular/router';
import { ViewBillComponentComponent } from './view-bill-component/view-bill-component.component';
import { ViewDriverDetailsComponentComponent } from './view-driver-details-component/view-driver-details-component.component';
import { AddDetailsComponent } from './add-details/add-details.component';
import { AuthGuardProviderSeekerService } from './auth-guard-provider-seeker.service';
import { AuthGuardseekerService } from './auth-guardseeker.service';
import { AuthGuardproviderService } from './auth-guardprovider.service';




const routes: Routes = [
  {path:"addcomponent", component:AddDetailsComponent,canActivate:[AuthGuardseekerService]},
  {path:"signup",component:SignupComponent},
  {path:'login',component:LoginComponent},
  {path:"menu",component:MenuComponent,canActivate:[AuthGuardProviderSeekerService]},
 
  {path:"viewBill", component:ViewBillComponentComponent,canActivate:[AuthGuardseekerService]},
  {path:"viewByDriver", component:ViewDriverDetailsComponentComponent,canActivate:[AuthGuardproviderService]},
  {path:'',redirectTo:'/login',pathMatch:'full'}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
