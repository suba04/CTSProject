import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewBillComponentComponent } from './view-bill-component.component';

describe('ViewBillComponentComponent', () => {
  let component: ViewBillComponentComponent;
  let fixture: ComponentFixture<ViewBillComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewBillComponentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewBillComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
