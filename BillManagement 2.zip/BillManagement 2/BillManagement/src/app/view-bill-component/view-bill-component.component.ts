import { Component, OnInit } from '@angular/core';
import { BillManagement } from '../bill-management';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { BillManagementService } from '../bill-management.service';
@Component({
  selector: 'app-view-bill-component',
  templateUrl: './view-bill-component.component.html',
  styleUrls: ['./view-bill-component.component.css']
})
export class ViewBillComponentComponent implements OnInit {
  viewBillFormGroup!:FormGroup;
  flag!:boolean;
  billManagementReport:BillManagement=new BillManagement();

  constructor(private billManagementService:BillManagementService) { }

  ngOnInit(): void {
    this.viewBillFormGroup=new FormGroup({
      billId:new FormControl('',[Validators.required, Validators.pattern(/^B\d{3}$/)])
     

    });
  }


  
  submitForm(){
  this.billManagementReport.billId=this.viewBillFormGroup.get('billId')?.value;
    this.view();
  }
  
  view(){
    this.billManagementService.viewBill(this.billManagementReport)
        .subscribe(data =>{
          this.billManagementReport=data;
          this.flag=true;
        },
        error=>{
          alert("Error:"+error.error);
          this.flag=false;
        }
          );
          
          this.billManagementReport=new BillManagement();
  }
}
