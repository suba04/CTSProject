import { TestBed } from '@angular/core/testing';

import { AuthGuardseekerService } from './auth-guardseeker.service';

describe('AuthGuardseekerService', () => {
  let service: AuthGuardseekerService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AuthGuardseekerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
