import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule } from '@angular/common/http';
import {FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ViewBillComponentComponent } from './view-bill-component/view-bill-component.component';
import { ViewDriverDetailsComponentComponent } from './view-driver-details-component/view-driver-details-component.component';
import { BillManagementService } from './bill-management.service';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { MenuComponent } from './menu/menu.component';
import { AddDetailsComponent } from './add-details/add-details.component';



@NgModule({
  declarations: [
    AppComponent,
    ViewBillComponentComponent,
    ViewDriverDetailsComponentComponent,
    LoginComponent,
    SignupComponent,
    MenuComponent,
    AddDetailsComponent,
  
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [], // to register classes, functions, or values 
  bootstrap: [AppComponent]
})
export class AppModule { }
