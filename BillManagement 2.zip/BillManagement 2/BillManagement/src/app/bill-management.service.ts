import { HttpClient, HttpHeaders, HttpResponse, HttpEvent } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BillManagement } from './bill-management';
import { DriverDetails } from './bill-management';

@Injectable({
  providedIn: 'root'
})
export class BillManagementService {

  constructor(private http:HttpClient) { }

  private loginUrl="http://localhost:8080/api/login";
  private addBillUrl:string='http://localhost:8080/api/bill/new';
  private viewBillUrl='http://localhost:8080/api/bill';
  private viewDriverUrl='http://localhost:8080/api/bill';
  private signupUrl="http://localhost:8080/api/signin";
  
  login(Login:any){
    return this.http.post<any>(this.loginUrl,Login);
    
  }
  addBill(BillManagement:any) :Observable<any>{
    return this.http.post<any>(this.addBillUrl,BillManagement);
  }
  viewBill(BillManagement:any):Observable<any>{
    return this.http.get<BillManagement>(this.viewBillUrl+"/"+BillManagement.billId);
  }
  viewDriver(BillManagement:any){
    return this.http.get<DriverDetails[]>(this.viewDriverUrl+"/"+BillManagement.month+"/"+BillManagement.driverId);
  }
  signupService(Login:any){
    return this.http.post<any>(this.signupUrl,Login);
  }
}
