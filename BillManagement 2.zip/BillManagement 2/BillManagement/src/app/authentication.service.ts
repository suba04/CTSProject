// brings functionality from external modules or libraries
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Login } from './bill-management';
import { firstValueFrom } from 'rxjs';

//Decorator used to mark a class to be provided & injected as dependency
@Injectable({
  providedIn: 'root'
})

export class AuthenticationService {

//constructor injects httpclient service into the AuthenticationService
  constructor(private http:HttpClient) { }


  authenticateURL:string="http://localhost:8080/api/login";

  user!: Login;
  authenticated!:boolean;
  users!: Login[];
  userBackend!:Login;
  
   async authenticate(login:any) {
   
    
     this.user=new Login();
     this.user.email=login.email;
     this.user.user_Role=login.user_Role;
     
     let valid : boolean;

     let data=await this.getUser(login);

     if(data){
      this.userBackend=new Login();
      this.userBackend.email=data.email;
      this.userBackend.user_Role=data.user_Role;

      valid =  this.user.user_Role===this.userBackend.user_Role && this.user.email==this.userBackend.email

      if(valid){
       
          this.authenticated=true;
          sessionStorage.setItem('user_Role', this.user.user_Role);
           sessionStorage.setItem('email',this.user.email);
        }else{
        alert("MailID with Password or role is mismatched ");
          this.authenticated=false;
     
        }
      }
      return this.authenticated;
    }

    getUser(login:any){
    //send a POST request to the authentication URL with login data and return the response
    //to change observalbe into promise
      return firstValueFrom(this.http.post<Login>(this.authenticateURL, login))
      .catch((err)=>{
        alert("MailId with Password or role is mismatched or mail Id hasn't registered")
      });
    }
  
    isUserLoggedIn() {
      let user_Role = sessionStorage.getItem('user_Role');
      let email = sessionStorage.getItem('email');
      console.log(!(email === null))
      return !(email === null && user_Role===null);
    }
    isUserRideProvider(){
      let user_Role=sessionStorage.getItem('user_Role');
      return (user_Role==='RideProvider');
    }
    isUserRideSeeker(){
      let user_Role=sessionStorage.getItem('user_Role');
      return (user_Role==='RideSeeker');
    }
  
    logOut() {
      sessionStorage.removeItem('email');
      sessionStorage.removeItem('user_Role');
    }

}
    






   
  
   
    
      
     
      

     
      


