import { Component, OnInit } from '@angular/core';
import { BillManagement } from '../bill-management';
import { FormGroup, FormControl,Validators, ValidationErrors, AbstractControl,ValidatorFn} from '@angular/forms';
import { BillManagementService } from '../bill-management.service';
import { NgModule } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-details',
  templateUrl: './add-details.component.html',
  styleUrls: ['./add-details.component.css']
})
export class AddDetailsComponent implements OnInit {

  add!:FormGroup;
  billId!:string;
  error!:string;
  result:boolean=false;

  constructor(private billservice:BillManagementService) { }
  billManagementReport:BillManagement=new BillManagement();

  ngOnInit(): void {
    this.add=new FormGroup({     //FormGroup instance required a parameter objective form control inside the paranthesis
     billId:new FormControl('',[Validators.required,Validators.pattern(/^B\d{3}$/)]), //creating new formControl instance for this
      rideId:new FormControl('',[Validators.required,Validators.pattern(/^RP[A-Za-z]{2}\d{2}$/)]),
      noOfKm:new FormControl('',[Validators.required,Validators.min(1),Validators.max(100)]),
      totalBill:new FormControl('',[Validators.required,Validators.min(100),Validators.max(5000)]),
      noOfOccupants:new FormControl('',[Validators.required,Validators.min(1),Validators.max(5)]),
      fees:new FormGroup({
        feeId:new FormControl('',[Validators.required,Validators.min(1),Validators.max(5)]),
        carType:new FormControl('',Validators.required),
        carName:new FormControl('',Validators.required),
        fuelType:new FormControl('',Validators.required),
        averageInKm:new FormControl('',[Validators.required,Validators.min(1),Validators.max(100)]),
        costOfFuel:new FormControl('',[Validators.required,Validators.min(100),Validators.max(2000)]),
        wearTearCost:new FormControl('',[Validators.required,Validators.min(1)]),
        driverCharges:new FormControl('',[Validators.required,Validators.min(100),Validators.max(500)]),
        carPoolCommision:new FormControl('',[Validators.required,Validators.pattern(/^50$/)]),

      }),
      costPerOccupant:new FormControl('',[Validators.required,Validators.min(1),Validators.max(500)]),

    });
  }

  onSubmit(){
    

    this.save();
    this.billManagementReport=new BillManagement();
          this.billId='';
          this.error='';
          this.result=false;
    
  }
  save(){
    this.billservice.addBill(this.add.value)
    //subscribe to an observable returned by method, handling async operations
        .subscribe(data =>{
          this.billId=JSON.stringify(data);//converting obj into json string
          if(data.message===this.add.get('billId')?.value){
            this.result=true;
            alert("Added successfully");
          }
          
        },
       
        error=>{
          this.error=error.error
          alert("The record is already present with the same Id in the database");
        }
          );
         
          
  }
}















































// function occupantsValidator(carName:string): ValidatorFn {
//   // const carName = control.parent?.get('carName')?.value; // Get carName from the parent FormGroup
//   const maxOccupantsMap: { [carName: string]: number } = {
//     'Volkswagen Golf': 5,
//     'Tesla Model 3': 5,
//     'Chevrolet Equinox': 5,
//     'Toyota Camry': 5,
//     'Toyota Prius': 5,
//   };

//   return (control: AbstractControl): ValidationErrors | null => {
//   const maxOccupants = maxOccupantsMap[carName];
//   const enteredValue = control.value;
//   if (maxOccupants !== undefined && enteredValue > maxOccupants) {
//     return { 'exceedsMaxOccupants': true };
//   }
//   return null;
// };

// }

