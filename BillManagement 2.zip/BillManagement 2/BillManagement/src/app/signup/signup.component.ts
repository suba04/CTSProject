import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl,FormGroup,Validators } from '@angular/forms';
import { BillManagementService } from '../bill-management.service';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private billManagementService:BillManagementService, private router:Router ) { }
  signupForm!:FormGroup;
  ngOnInit(): void {
    this.signupForm=new FormGroup({
      user_Name:new FormControl('userProvider',Validators.required),
      email:new FormControl('provider1@gmail.com',[Validators.required,Validators.pattern("^[a-z0-9]+@gmail\.com$")]),
      user_Role:new FormControl('',Validators.required),
      password:new FormControl('user01',[Validators.required,Validators.maxLength(6)])
    });
  }
  
  onSubmit(){
    this.signUp();
  }
  signUp(){
   this.billManagementService.signupService(this.signupForm.value)
    .subscribe(data=>{
      alert(data.message);
      this.router.navigateByUrl('login');
    },
    error=>{
      alert(error.error);
    });
   
  }
}